#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>

int newsocket(int family, int type, int protocol);
int newbind(int fd, const struct sockaddr *addr, socklen_t addrlen);
ssize_t newrecvfrom(int fd, void *buf, size_t buflen,int flags, struct sockaddr *from,socklen_t *addrlen);
ssize_t newsendto(int fd, const void *buf, size_t buflen,int flags, const struct sockaddr *to,socklen_t addrlen);
int newclose(int fd);
int newconnect(int fd,const struct sockaddr *addr,size_t len);
ssize_t newrecv(int fd, void *buf, size_t buflen, int flags);
ssize_t newsend (int fd, const void *buf, size_t buflen,  int flags);