#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "socket.h"

int newsocket(int family, int type, int protocol){
	int fd = 0;
	
	if ((fd = socket(family, type, protocol)) < 0) {
		perror("socket");
		exit(-1);
	}
	
	return fd;
}

int newbind(int fd, const struct sockaddr *addr, socklen_t addrlen){
	
	if (bind(fd, addr, addrlen) != 0) {
		perror("bind");
		exit(-1);
	}
	
	return 0;
}

ssize_t newrecvfrom(int fd, void *buf, size_t buflen,int flags, struct sockaddr *from,socklen_t *addrlen){
	ssize_t len = 0;
	
	len = recvfrom(fd, buf, buflen, flags, from, addrlen);
	if (len < 0) {
		perror("recvfrom");
		exit(-1);
	}
	
	return len;
}

ssize_t newsendto(int fd, const void *buf, size_t buflen,int flags, const struct sockaddr *to,socklen_t addrlen){
	ssize_t len;
	
	if ((len = sendto(fd, buf, buflen, flags, to, addrlen)) < 0) {
		perror("sendto");
		exit(-1);
	}
	
	return len;
}

int newclose(int fd){
	if (close(fd) < 0){
		perror("close");
		exit(-1);
	}
	
	return 0;
}

int newconnect(int fd,const struct sockaddr *addr,size_t len){
	if (connect(fd, addr, len) < 0){
		perror("connect");
		exit(-1);
	}
	
	return 0;
}

ssize_t newrecv(int fd, void *buf, size_t buflen, int flags){
	ssize_t len;
	
	if ((len = recv(fd, buf, buflen, flags)) < 0) {
		perror("recv");
		exit(-1);
	}
	
	return len;
}

ssize_t newsend (int fd, const void *buf, size_t buflen,  int flags){
	ssize_t len;
	
	if ((len = send(fd, buf, buflen, flags)) < 0) {
		perror("send");
		exit(-1);
	}
	
	return len;
}