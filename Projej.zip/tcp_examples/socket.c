#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include "socket.h"

int newsocket(int family, int type, int protocol){
	int fd = 0;
	
	if ((fd = socket(family, type, protocol)) < 0) {
		perror("socket");
		exit(-1);
	}
	
	return fd;
}

int newbind(int fd, const struct sockaddr *addr, socklen_t addrlen){
	
	if (bind(fd, addr, addrlen) != 0) {
		perror("bind");
		exit(-1);
	}
	
	return 0;
}

ssize_t newrecvfrom(int fd, void *buf, size_t buflen,int flags, struct sockaddr *from,socklen_t *addrlen){
	ssize_t len = 0;
	
	len = recvfrom(fd, buf, buflen, flags, from, addrlen);
	if (len < 0) {
		perror("recvfrom");
		exit(-1);
	}
	
	return len;
}

ssize_t newsendto(int fd, const void *buf, size_t buflen,int flags, const struct sockaddr *to,socklen_t addrlen){
	ssize_t len;
	
	if ((len = sendto(fd, buf, buflen, flags, to, addrlen)) < 0) {
		perror("sendto");
		exit(-1);
	}
	
	return len;
}

int newclose(int fd){
	if (close(fd) < 0){
		perror("close");
		exit(-1);
	}
	
	return 0;
}

int newconnect(int fd,const struct sockaddr *addr,size_t len){
	if (connect(fd, addr, len) < 0){
		perror("connect");
		exit(-1);
	}
	
	return 0;
}

ssize_t newrecv(int fd, void *buf, size_t buflen, int flags){
	ssize_t len;
	
	if ((len = recv(fd, buf, buflen, flags)) < 0) {
		perror("recv");
		exit(-1);
	}
	
	return len;
}

ssize_t newsend (int fd, const void *buf, size_t buflen,  int flags){
	ssize_t len;
	
	if ((len = send(fd, buf, buflen, flags)) < 0) {
		perror("send");
		exit(-1);
	}
	
	return len;
}

int newselect(int nfds, fd_set *readfds,fd_set *writefds,fd_set *exceptfds,struct timeval *timeout){
	int fd = 0;
	
	if ((fd = select(nfds, readfds, writefds, exceptfds, timeout)) <= 0) {
		perror("select");
		exit(-1);
	}
	
	return fd;
}

int newshutdown(int fd, int how){
	
	if (shutdown(fd, how) < 0){
		perror("shutdown");
		exit(-1);
	}
	
	return 0;
}

int newlisten(int fd, int backlog){
	
	if (listen(fd, backlog) < 0){
		perror("listen");
		exit(-1);
	}
	
	return 0;
}

int newaccept(int fd, struct sockaddr* addr, socklen_t *len){
	int newfd = 0;
	
	if ((newfd = accept(fd, addr, len)) < 0) {
		perror("accept");
		exit(-1);
	}
	
	return newfd;
}

ssize_t newread(int fd, void *buf, size_t len){
	ssize_t newlen;
	
	if ((newlen = read(fd, buf, len)) < 0) {
		perror("read");
		exit(-1);
	}
	
	return newlen;
}

ssize_t newwrite(int fd, const void *buf, size_t len){
	ssize_t newlen;
	
	if ((newlen = write(fd, buf, len)) < 0) {
		perror("write");
		exit(-1);
	}
	
	return newlen;
}