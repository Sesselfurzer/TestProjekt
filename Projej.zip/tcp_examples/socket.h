#include <sys/types.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <unistd.h>
#include <string.h>
#include <stdio.h>
#include <sys/select.h>
int newsocket(int family, int type, int protocol);
int newbind(int fd, const struct sockaddr *addr, socklen_t addrlen);
ssize_t newrecvfrom(int fd, void *buf, size_t buflen,int flags, struct sockaddr *from,socklen_t *addrlen);
ssize_t newsendto(int fd, const void *buf, size_t buflen,int flags, const struct sockaddr *to,socklen_t addrlen);
int newclose(int fd);
int newconnect(int fd,const struct sockaddr *addr,size_t len);
ssize_t newrecv(int fd, void *buf, size_t buflen, int flags);
ssize_t newsend (int fd, const void *buf, size_t buflen,  int flags);
int newselect(int nfds, fd_set *readfds,fd_set *writefds,fd_set *exceptfds,struct timeval *timeout);
int newshutdown(int fd, int how);
int newlisten(int fd, int backlog);
int newaccept(int fd, struct sockaddr* addr, socklen_t *len);
ssize_t newread(int fd, void *buf, size_t len);
ssize_t newwrite(int fd, const void *buf, size_t len);