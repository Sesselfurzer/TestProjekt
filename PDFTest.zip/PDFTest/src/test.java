
import java.io.File;
import java.io.IOException;

import org.apache.pdfbox.cos.COSName;
import org.apache.pdfbox.pdmodel.PDDocument;
import org.apache.pdfbox.pdmodel.PDPage;
import org.apache.pdfbox.pdmodel.PDPageContentStream;
import org.apache.pdfbox.pdmodel.PDResources;
import org.apache.pdfbox.pdmodel.common.PDRectangle;
import org.apache.pdfbox.pdmodel.font.PDFont;
import org.apache.pdfbox.pdmodel.font.PDType1Font;
import org.apache.pdfbox.pdmodel.interactive.annotation.PDAnnotationWidget;
import org.apache.pdfbox.pdmodel.interactive.form.PDAcroForm;
import org.apache.pdfbox.pdmodel.interactive.form.PDTextField;

public class test {

  public static void main(String[] args) throws IOException {

    // PDDocument.load(new File("Pfad")) für bearbeiten von einer form
    //File file = new File("SimpleForm.pdf");
    PDDocument document = new PDDocument();
    PDPage page =  new PDPage(PDRectangle.A4);
    document.addPage(page);

    // Schriftart
    PDFont font = PDType1Font.HELVETICA;
    PDResources resources = new PDResources();
    resources.put(COSName.getPDFName("Helv"), font);

    PDAcroForm acroForm = new PDAcroForm(document);
    document.getDocumentCatalog().setAcroForm(acroForm);

    acroForm.setDefaultResources(resources);

    // Schriftgröße/farbe
    String defaultAppearanceString = "/Helv 0 Tf 1 0 1 rg";
    acroForm.setDefaultAppearance(defaultAppearanceString);

    // textbox
    PDTextField textBox = new PDTextField(acroForm);

    PDAnnotationWidget widget = textBox.getWidgets().get(0);
    PDRectangle rect = new PDRectangle(50, 750, 200, 50);
    widget.setRectangle(rect);
    widget.setPage(page);
    widget.setPrinted(true);
    page.getAnnotations().add(widget);
    textBox.setValue("Sample field");

    PDPageContentStream content = new PDPageContentStream(document, page);
    content.beginText();
    content.setFont(PDType1Font.TIMES_ROMAN, 12);
    content.newLineAtOffset(25, 500);
    content.showText("Marvin ist kacke");
    content.endText();
    content.close();
    document.save("SimpleForm.pdf");

    document.close();

  }
}
