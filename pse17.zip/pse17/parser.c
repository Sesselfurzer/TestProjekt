//
// Created by Dominik Roß on 17.04.18.
//
#include "parser.h"
#include "strynglib.h"
#include "attributes.h"
#include "response.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>




/**
 * Parses an HTTP request by a given request.
 * @param request_str HTTP Request
 * @return Complete response
 */
Stryng parse(Stryng request_str)
{
    /*
     * Init the custom String Library. It works without zero terminated strings
     */
    stryngInit();

    Request request;
    Response response;
    int response_code = 200;
    request.attributes = initAttributesList();
    response.attributes = initAttributesList();

    /*
     * Split the HTTP request into an array of Stryng based on the CRLF
     * of HTTP '\r\n'
     */
    int line_count = Stryngs.count(request_str, "\r\n");

    /*
     * If there is no CRLF it is an bad request
     */
    if (line_count == 0)
        response_code = 400;

    if(response_code == 200) {
        Stryng request_split[line_count];
        /*
         * Split the lines seperated by the CRLF into an array. Initialize the items as
         * NULL.
         */
        for(int i = 0; i < line_count; i++)
        {
            request_split[i].text = NULL;
        }

        int splitted = Stryngs.splitC(request_str, &request_split, "\r\n", line_count, 1);

        if(request_split[0].text == NULL)//The requestline is NULL, bad request
        {
            response_code = 400;
        }

        else {
            /*
             * Create request struct. All information of the HTTP-request
             * will be formatted into structs.
             */
            request.requestLine = readRequestLine(request_split[0], &response_code);
            if (response_code == 200) //No error until now?
            {
                readAttributes(request.attributes, &request_split[1], splitted - 1, &response_code);
                if (response_code == 400) { //If there is an invalid attribute it is an bad request an clear the requestline
                    Stryngs.liberate(&request.requestLine.resource);
                    Stryngs.liberate(&request.requestLine.method);
                    Stryngs.liberate(&request.requestLine.version);
                }
            }

        }
        for (int i = 0; i < line_count; i++) {
            if(request_split[i].text != NULL)
                Stryngs.liberate(&request_split[i]); //Free all lines (if they are not null)
        }
    }


    /**
     * Generate response
     */
    Stryng response_text = generate_response(&response, &request, &response_code);

    clearAttributesList(response.attributes);
    clearAttributesList(request.attributes);
    if(response_code != 400 && response_code !=501) { //Maybe requestline  the requestline is not set
        Stryngs.liberate(&request.requestLine.resource);
        Stryngs.liberate(&request.requestLine.method);
        Stryngs.liberate(&request.requestLine.version);
    }
    Stryngs.liberate(&response.statusLine.reasonPhrase);
    Stryngs.liberate(&response.statusLine.code);
    Stryngs.liberate(&response.statusLine.version);


    return response_text;
}

/**
 * Reads the request line of the HTTP request like 'GET / HTTP/1.1' and returns
 * it as an struct with the relevant attributes 'METHOD', 'VERSION' and 'RESOURCE'
 * @param line request line
 * @param response_code status code that gets changed if something doesnt work as intended
 * @return struct of request line
 */
RequestLine readRequestLine(Stryng line, int *response_code)
{

    Stryng requestline_str[line.length];
    int splitted = Stryngs.split(line, &requestline_str ,' ',3,1); //Split requestline with ' '
    RequestLine requestLine;
    if(splitted < 2)
    {
        for(int i = 0; i <= splitted; i++) {
            Stryngs.liberate(&requestline_str[i]);
        }
        *response_code = 400;
        return requestLine;
    }
    char filter[2]=" ";
    stryngFilter(filter, &(requestline_str[2]),1); //Delete whitespaces

    if(stryngFind(requestline_str[0], "GET")==3){
        Stryngs.decode(&requestline_str[1]); //Get the decoded path
        requestLine.method = requestline_str[0];

        stryngModulate(&requestline_str[1], requestline_str[1].length + 1); //make 1 larger, to append \0
        requestline_str[1].text[requestline_str[1].length-1] = '\0';

        requestLine.resource = requestline_str[1];
        requestLine.version = requestline_str[2];
    }else {
        for(int i = 0; i <= splitted; i++) {
            Stryngs.liberate(&requestline_str[i]);
        }
        *response_code = 501;
    }
    if(splitted > 2) {
        for(int i = 3; i <= splitted; i++) {
            Stryngs.liberate(&requestline_str[i]);
        }
    }

    return requestLine;
}



/**
 * Returns the debug page with the properties METHOD, RESOURCE and VERSION
 * @param request request
 * @return complete http response
 */
Stryng getDebugPage(Request request)
{
    Stryng version[2];
    stryngSplit(request.requestLine.version, &version,'/',1,1);

    char method_text[] = {"\n<html>\n <body>\n  <h1>Willkommen im externen Bereich!</h1>\n  <pre> \nHTTP-Methode:"};
    char resource_text[] = {"\nHTTP-Ressource:"};
    char version_text[] = {"\nHTTP-Protokoll-Version:"};
    char end_text[] = {"\n  </pre>\n </body>\n</html> "};

    Stryng debugPagePieces[7]={Stryngs.new(method_text,strlen(method_text)),
                               request.requestLine.method,
                               Stryngs.new(resource_text, strlen(resource_text)),
                               request.requestLine.resource,
                               Stryngs.new(version_text, strlen(version_text)),
                               version[1],
                               Stryngs.new(end_text,strlen(end_text))};
    Stryng debugPageText;
    Stryngs.join(debugPagePieces, &debugPageText, " ",7); //Concatenate the page
    //Free the pieces
    Stryngs.liberate(&debugPagePieces[0]);
    Stryngs.liberate(&debugPagePieces[2]);
    Stryngs.liberate(&debugPagePieces[4]);
    Stryngs.liberate(&debugPagePieces[6]);
    Stryngs.liberate(&version[0]);
    Stryngs.liberate(&version[1]);
    return debugPageText;
}







