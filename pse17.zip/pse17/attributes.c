//
// Created by ms150591 on 25.04.18.
//
#include "parser.h"
#include "strynglib.h"
#include "attributes.h"
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
/**
 * Creates an linked list of the attributes based on the sent HTTP request.
 * NOTICE that the first element is set to an NULL dummy-element
 * @param lines All attributes except the request line
 * @param attr_count Attribute count
 * @param code statuscode that gets changed if something doesnt work out
 * @param list all the attributes will be saved into this list
 */
void readAttributes(AttributesList *list, Stryng lines[], int attr_count, int* code)
{
    Attribute nextAttribute;

    /*
     *  Append all send attributes to attributes list
     */
    for(int i = 0; i < attr_count; i++)
    {
        if(lines[i].text!=NULL) {
            nextAttribute = getAttribute(&lines[i], code);
            if (*code != 200)
                break;
            appendAttribute(list, nextAttribute);
        }
    }

}

/**
 * Splits an attribute-string like 'Cache-Control: max-age=0'into an
 * struct of Attribute with the properties 'NAME' and 'VALUE' '
 * @param attribute_str Unformatted Attribute-Stryng
 * @param code statuscode that gets changed if something doesnt work out
 * @return Formatted Attribute-struct
 */
Attribute getAttribute(Stryng *attribute_str, int* code)
{
    /*
     * Create Attribute struct
     */
    Attribute attribute;

    /*
     * Deleting spaces
     */
    char filtersymbols[2]=" ";
    stryngFilter(filtersymbols,attribute_str, 1);

    /*
     * Split the Attribute token
     */
    Stryng attribute_split[2];
    int splitted = Stryngs.split(*attribute_str, &attribute_split, ':', 1, 1);

    //Stryngs.liberate(attribute_str);

    /*
     * If there a not exactly two parts something went wrong
     * We need 'NAME' and 'VALUE'
     */
    if (splitted != 1)
    {
        Stryngs.liberate(&attribute_split[0]);
        //Stryngs.liberate(&attribute_split[1]);

        *code=400;
    }
    else
    {
        /*
         * Name is the first parameter, value the second
         */
        attribute.name = attribute_split[0];
        attribute.value = attribute_split[1];
    }

    return attribute;
}

/**
 * Append a given attribute to the linked list of attributes
 * @param list Linked Attributes-List
 * @param attribute Attribute to append
 */
void appendAttribute(AttributesList *list, Attribute attribute)
{
    /*
     * Goto last list attribute
     */
    AttributesList *currentEl = list;
    while(currentEl->next != NULL)
        currentEl = currentEl->next;

    /*
     * Create new attribute, set next element to NULL
     */
    AttributesList *newEl = gimme(1, sizeof(struct AttributesList));
    newEl->attribute = attribute;
    newEl->next = NULL;

    /*
     * Save new element in list
     */
    currentEl->next = newEl;
}

/**
 * add a given attribute to the linked list of attributes with 2 Stryngs
 * @param list Linked Attributes-List
 * @param name,value Attribute as 2 Stryngs
 */
void addAttribute(AttributesList *list, Stryng name, Stryng value)
{
    Attribute newAttribute;

    newAttribute.name = name;
    newAttribute.value = value;
    appendAttribute(list, newAttribute);
}

/**
 * Initializes the linked AttributesList
 * NOTICE that the first element is set to an NULL dummy-element
 * @return first dummy element
 */
AttributesList* initAttributesList()
{
    AttributesList *first = gimme(1, sizeof(struct AttributesList));
    first->next = NULL;
    return first;
}


/**
 * Find an given attribute in the list
 * @param list Linked Attributes-List
 * @param attributeName search this attribute name in the list
 * @param attribute Stryng for the value of the attribute that got found
 * @return TRUE if the attribute was found else FALSE
 */
int findAttribute(char* attributeName, AttributesList *list, Stryng *attribute)
{
    AttributesList *currentEl = list;
    while(currentEl->next !=NULL)
    {
        Stryngs.toLower(&currentEl->attribute.name);
        Stryngs.toLower(&currentEl->attribute.value);
        if(Stryngs.find(currentEl->attribute.name, attributeName)==strlen(attributeName))
        {
            *attribute = currentEl->attribute.value;
            return TRUE;
        }
        currentEl = currentEl->next;
    }
    return FALSE;
}

/**
 * Deletes all items of an AttributeList
 * @param list first (dummy) element of list
 */
void clearAttributesList(AttributesList *list)
{
    struct AttributesList *p, *p1; //temp pointer

    /*
     * If the list exists
     */
    if (list != NULL) {
        /*
         * Go through the list and delete the items
         */
        p = list->next;
        while (p != NULL) {
            p1 = list->next->next;
            list->next = p1;
            freeAttributesListItem(p);
            p = p1;
        }
        /*
         * Delete the first elements of the list */
        //freeAttributesListItem(list->next);
        freeAttributesListItem(list);
        list = NULL;
    }
}

/**
 * Frees an item of the AttributesList and it's Stryngs
 * @param item the item to delete
 */
void freeAttributesListItem(AttributesList *item)
{
    /*
     * First free the Stryngs
     */
    Stryngs.liberate(&(item->attribute.name));
    Stryngs.liberate(&(item->attribute.value));
    /*
     * After that free the item
     */
    free(item);
}
