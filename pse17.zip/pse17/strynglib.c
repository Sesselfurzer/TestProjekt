//
// Created by Nick Lohmann on 15.04.18.
//

#include "strynglib.h"
#include <stdlib.h>
#include <stdio.h>
#include <memory.h>

//! Creativly named wrapper function for calloc() that should wait for free memory if neccessary
/*!
  \param amount number of elements
  \param size the size(bytes) to be allocated
  \return pointer to the alloc
*/
void *gimme(int amount, int size) {
    void *p = NULL;
    int counter = 0, cycles = 0;
    do {
        if (counter != 0) {
            counter--;
        } else {
            p = calloc((size_t) amount, (size_t) size);
            if (p == NULL) {
                cycles++;
                counter = cycles < ALLOC_DELAY_FACTOR_MAX / 10 ? cycles * 10 : ALLOC_DELAY_FACTOR_MAX;
            }
        }
    } while (p == NULL);
    return p;
}


//! Global instance of Strynger (pointer library for Stryng) note:I don't even know if this works in a library
Strynger Stryngs;


//! Copies text from one Stryng into another
/*!
  \param source the Stryng that is to be copied
  \param amount the amount of Symbols to be written, starts at [0]
  \return the Stryng that is to be written into
*/
Stryng stryngCopy(Stryng source, int amount) {
    Stryng target = Stryngs.new("", amount);
    for (int i = 0; i < amount && i < source.length; i++) {
        (target).text[i] = source.text[i];
    }
    return target;
}

//! Copies text from one Stryng into another, with indent
/*!
  \param source the Stryng that is to be copied
  \param amount the amount of Symbols to be written, starts at indent
  \param indent where we start copying
  \return the Stryng that is to be written into
*/
Stryng stryngCopyFrom(Stryng source, int amount, int indent) {
    Stryng target = Stryngs.new("", amount);
    for (int i = indent; i < amount && i < source.length; i++) {
        (target).text[i] = source.text[i];
    }
    return target;
}

//! Internal function, use at your own peril. Writes a char* into a Stryng.text field
/*!
  \param source the char* that is to be written
  \param target the Stryng that is to be written into
  \param amount the amount of Symbols to be written, ideally the size of both source and target
*/
void stryngWrite(char *source, Stryng *target, int amount) {
    for (int i = 0; i < amount && i < target->length; i++) {
        target->text[i] = source[i];
    }
}


//! internal function, use at your own peril. stryng-specific wrapper for realloc
/*!
  \param ptr the pointer to the to-be-reallocated memory
  \param amount the amount of Symbols to be written and new size of ptr
  \return the reallocated pointer
*/
Stryng *stryngModulate(Stryng *ptr, int amount) {
    char *p = NULL;
    int counter = 0, cycles = 0;
    do {
        if (counter > 0) {
            counter--;
        } else {
            p = realloc(ptr->text, (size_t) amount);
            if (p == NULL) {
                cycles++;
                counter = cycles < ALLOC_DELAY_FACTOR_MAX / 10 ? cycles * 10 : ALLOC_DELAY_FACTOR_MAX;
            }
        }
    } while (p == NULL);
    //free(ptr->text);
    ptr->text = p;
    ptr->length = amount;
    return ptr;
}

//! Pseudo concat
/*!
  \param source the char* that is to be added
  \param target the Stryng that is to be written into
  \param amount the amount of Symbols to be written, ideally the size of source
  \return the new length of target (if 0, something probably fucked up)
*/
int stryngConcat(char *source, Stryng *target, int amount) {
    stryngModulate(target, target->length + amount);
    for (int i = 0; i < amount && i < target->length; i++) {
        (*target).text[i] = source[i];
    }
    return target->length;
}

//! Creates a new Stryng (allocates memory and sets text and length)
/*!
  \param text the text to be written into the Stryngs .text field
  \param length the amount of memory allocated and the size of text which is written into the Stryngs .length field
  \return the created Stryng
*/
Stryng stryngNew(char *text, int length) {
    Stryng val;
    val.length = length;
    val.text = (char *) gimme(length + 1, sizeof(char));;
    stryngWrite(text, &val, length);
    val.text[length] = '\0';
    //slAdd(&val);
    return val;
}

//! Frees allocated memory from a Stryng and sets its size to 0
/*!
  \param target the target Stryng
*/
void stryngLiberate(Stryng *target) {
    free(target->text);
    target->length = 0;
    target->text = NULL;
}

//! Splits the Stryng into an Array of Stryng
/*!
  \param source the Stryng that is to be split
  \param target[] the target Array (do not initialize with stryngNew or Stryngs.New, will leak memory)
  \param symbol the symbol at which the Stryng is split
  \param maxSplit the amount of splits that can be made, should be the size of target[] or smaller
  \param deleteEmpty if this is >0, any empty Arrays will not be written into target (note that this does not fill up or delete the remaining space in the array)
  \return the amount of splits made
*/
int stryngSplit(Stryng source, Stryng (*target)[], char symbol, int maxSplit, int deleteEmpty) {
    int amountOfSplits = 0, counter = 0, internCounter = 0;
    char strings[maxSplit][source.length];
    int lengths[maxSplit];
    while (amountOfSplits <= maxSplit && counter < source.length) { //go trough the whole text
        if (source.text[counter] == symbol && maxSplit != amountOfSplits) { //oh look, we found our target
            lengths[amountOfSplits] = internCounter;
            if (internCounter != 0) {
                amountOfSplits++;
            }
            internCounter = -1;
        } else { //nope, just write that char into the buffer
            strings[amountOfSplits][internCounter] = source.text[counter];
        }
        internCounter++;
        counter++;
    } //good, now to write that shit into the target stryngs
    int returner = -1;
    lengths[amountOfSplits] = internCounter;
    for (int i = 0; i <= amountOfSplits; i++) {
        if ((deleteEmpty && lengths[i]) || !deleteEmpty) {
            (*target)[i] = stryngNew(strings[i], lengths[i]);
            /*(*target)[i].text = (char *) gimme(lengths[i]+1, sizeof(char));
            stryngWrite(strings[i], &(*target)[i], lengths[i]);
            (*target)[i].length = lengths[i];*/
            returner++;
        }
    }
    return returner;
}

//! Splits the Stryng into an Array of Stryng by another Stryng
/*!
  \param source the Stryng that is to be split
  \param target[] the target Array (do not initialize with stryngNew or Stryngs.New, will leak memory)
  \param symbol the Stryng at which the source is split
  \param maxSplit the amount of splits that can be made, should be the size of target[] or smaller
  \param deleteEmpty if this is >0, any empty Arrays will not be written into target (note that this does not fill up or delete the remaining space in the array)
  \return the amount of splits made
*/
int stryngSplitL(Stryng source, Stryng (*target)[], Stryng symbol, int maxSplit, int deleteEmpty) {
    int amountOfSplits = 0, counter = 0, internCounter = 0;
    char strings[maxSplit][source.length];
    int lengths[maxSplit], setter = 0;
    while (amountOfSplits <= maxSplit && counter < source.length) { //go trough the whole text
        if (source.text[counter] == symbol.text[setter] && maxSplit != amountOfSplits) { //oh look, we found our target
            setter++;
            if (setter >= symbol.length) {
                lengths[amountOfSplits] = internCounter - (symbol.length - 1);
                if (internCounter != 0) {
                    amountOfSplits++;
                }
                internCounter = -1;
                setter = 0;
            }
        } else { //nope, just write that char into the buffer
            setter = 0;
            strings[amountOfSplits][internCounter] = source.text[counter];
        }
        internCounter++;
        counter++;
    } //good, now to write that shit into the target stryngs
    int returner = -1;
    lengths[amountOfSplits] = internCounter;
    for (int i = 0; i <= amountOfSplits; i++) {
        if ((deleteEmpty && lengths[i]) || !deleteEmpty) {
            (*target)[i] = stryngNew(strings[i], lengths[i]);
            /*(*target)[i].text = (char *) gimme(lengths[i]+1, sizeof(char));
            stryngWrite(strings[i], &(*target)[i], lengths[i]);
            (*target)[i].length = lengths[i];*/
            returner++;
        }
    }
    return returner;
}

//! Splits the Stryng into an Array of Stryng by a char*
/*!
  \param source the Stryng that is to be split
  \param target[] the target Array (do not initialize with stryngNew or Stryngs.New, will leak memory)
  \param symbol the char* at which the source is split
  \param maxSplit the amount of splits that can be made, should be the size of target[] or smaller
  \param deleteEmpty if this is >0, any empty Arrays will not be written into target (note that this does not fill up or delete the remaining space in the array)
  \return the amount of splits made
*/
int stryngSplitC(Stryng source, Stryng (*target)[], char *symbol, int maxSplit, int deleteEmpty) {
    int amountOfSplits = 0, counter = 0, internCounter = 0, symlen = (int) strlen(symbol);
    char strings[maxSplit][source.length];
    int lengths[maxSplit], setter = 0;
    while (amountOfSplits <= maxSplit && counter < source.length) { //go trough the whole text
        if (source.text[counter] == symbol[setter] && maxSplit != amountOfSplits) { //oh look, we found our target
            setter++;
            if (setter >= symlen) {
                lengths[amountOfSplits] = internCounter - (symlen - 1);
                if (internCounter != 0) {
                    amountOfSplits++;
                }
                internCounter = -1;
                setter = 0;
            }
        } else { //nope, just write that char into the buffer
            setter = 0;
            strings[amountOfSplits][internCounter] = source.text[counter];
        }
        internCounter++;
        counter++;
    } //good, now to write that shit into the target stryngs
    int returner = 0;
    lengths[amountOfSplits] = internCounter;
    for (int i = 0; i < amountOfSplits; i++) {
        if ((deleteEmpty && lengths[i]) || !deleteEmpty) {
            (*target)[i] = stryngNew(strings[i], lengths[i]);
            /*(*target)[i].text = (char *) gimme(lengths[i]+1, sizeof(char));
            stryngWrite(strings[i], &(*target)[i], lengths[i]);
            (*target)[i].length = lengths[i];*/
            returner++;
        }
    }
    return returner;
}

//! Joins an Array of Stryng into a single one, with separators
/*!
  \param source[] Stryng Array that is to be joined
  \param target the target Stryng (do not initialize with stryngNew or Stryngs.New, will leak memory)
  \param separator the char* that is placed in between the source texts (make sure format is corrent)
  \param sizeOfSource the size of the Source Array, since there is no way to read it within the function
*/
void stryngJoin(Stryng source[], Stryng *target, char *separator, int sizeOfSource) {
    int sizeTotal = 0, seplen = (int) strlen(separator);
    for (int i = 0; i < sizeOfSource; i++) {
        sizeTotal += source[i].length;
    }
    sizeTotal += seplen * (sizeOfSource - 1);
    char buffer[sizeTotal];
    int counter = 0;
    for (int i = 0; i < sizeOfSource; i++) {
        for (int j = 0; j < source[i].length; j++) {
            buffer[counter] = source[i].text[j];
            counter++;
        }
        for (int j = 0; j < seplen; j++) {
            buffer[counter] = separator[j];
            counter++;
        }
    }
    *target = stryngNew(buffer, sizeTotal);
    /*slAdd(target);
    target->text = (char *) gimme(sizeTotal, sizeof(char));
    stryngWrite(buffer, target, sizeTotal);
    target->length = sizeTotal;*/
}

//! Joins an Array of Stryng into a single one
/*!
  \param source[] Stryng Array that is to be joined
  \param target the target Stryng (do not initialize with stryngNew or Stryngs.New, will leak memory)
  \param sizeOfSource the size of the source Array, since there is no way to read it within the function
*/
void stryngFuse(Stryng source[], Stryng *target, int sizeOfSource) {
    int sizeTotal = 0;
    for (int i = 0; i < sizeOfSource; i++) {
        sizeTotal += source[i].length;
    }
    char buffer[sizeTotal];
    int counter = 0;
    for (int i = 0; i < sizeOfSource; i++) {
        for (int j = 0; j < source[i].length; j++) {
            buffer[counter] = source[i].text[j];
            counter++;
        }
    }
    *target = stryngNew(buffer, sizeTotal);
    /*slAdd(target);
    target->text = (char *) gimme(sizeTotal, sizeof(char));
    stryngWrite(buffer, target, sizeTotal);
    target->length = sizeTotal;*/
}

//! Decodes an URI encoded Stryng
/*!
  \param target the Stryng to be decoded
  \return the amount of Symbols decoded
*/
int stryngDecoder(Stryng *target) {
    /*char table[30][3] = {{' ',  '2', '0'}, yes, i made a damn table cause i didn't notice that those
                         {'!',  '2', '1'},   shitty symbols are just corresponding to the ascii hex codes.
                         {'"',  '2', '2'},
                         {'#',  '2', '3'},
                         {'$',  '2', '4'},
                         {'%',  '2', '5'},
                         {'&',  '2', '6'},
                         {'\'', '2', '7'},
                         {'(',  '2', '8'},
                         {')',  '2', '9'},
                         {'*',  '2', 'a'},
                         {'+',  '2', 'b'},
                         {',',  '2', 'c'},
                         {'-',  '2', 'd'},
                         {'.',  '2', 'e'},
                         {'/',  '2', 'f'},
                         {':',  '3', 'a'},
                         {';',  '3', 'b'},
                         {'<',  '3', 'c'},
                         {'=',  '3', 'd'},
                         {'>',  '3', 'e'},
                         {'?',  '3', 'f'},
                         {'@',  '4', '0'},
                         {'[',  '5', 'b'},
                         {'\\', '5', 'c'},
                         {']',  '5', 'd'},
                         {'{',  '7', 'b'},
                         {'|',  '7', 'c'},
                         {'}',  '7', 'd'},
                         {' ',  ' ', ' '}};*/
    char buffer[target->length], codeBuffer[2], symBuffer;
    int setter = 0, counter = 0, returner = 0;
    for (int i = 0; i < target->length; i++) { //for every symbol...
        if (target->text[i] == '%') { //check if we got a %
            setter = 1;
        } else if (setter) { //if so, then the next two
            codeBuffer[setter - 1] = target->text[i]; //get saved
            if (setter >= 2) {
                /*int j = 0; //so we can search them # remnant of the code for the table, left so it can be reverted
                while (!(table[j][1] == codeBuffer[0] && table[j][2] == codeBuffer[1]) && j <= 30) {
                    //go trough the entire f**in table cause we need to
                    j++;
                }
                symBuffer = table[j][0];
                if (j >= 31) { //ran trough all of them negative
                    buffer[counter] = '%';
                    buffer[counter + 1] = codeBuffer[0];
                    buffer[counter + 2] = codeBuffer[1];
                    counter += 3;
                } else { //got a hit
                    buffer[counter] = symBuffer;
                    returner++;
                    counter++;
                }*/
                int j = (char)hexToInt(codeBuffer, 2);
                if (j > 126 || j < 32) { //yeah, no. no fancy shit in my urls. feel free to change to your own risk.
                    buffer[counter] = '%';
                    buffer[counter + 1] = codeBuffer[0];
                    buffer[counter + 2] = codeBuffer[1];
                    counter += 3;
                } else { //some 'valid' symbol
                    buffer[counter] = (char)j;
                    returner++;
                    counter++;
                }
                setter = 0;
            } else {
                setter++;
            }
        } else { //otherwise just write it into the buffer like nothing happened
            buffer[counter] = target->text[i];
            counter++;
        }
    }
    //stryngLiberate(target);
    //target = stryngNew(buffer, counter);

    stryngModulate(target, counter);
    stryngWrite(buffer, target, target->length);

    /*slAdd(target);
    target->text = (char *) gimme(counter, sizeof(char));
    stryngWrite(buffer, target, counter);
    target->length = counter;
    return returner;*/
}

//! Filters out a certain set of symbols
/*!
  \param filter Symbols to be filtered
  \param target the target Stryng
  \param filterSize amount of Symbols in the filter Array
  \return the amount of Symbols deleted
*/
int stryngFilter(char filter[], Stryng *target, int filterSize) {
    char buffer[target->length];
    int counter = 0, toFilter = 0;
    for (int i = 0; i < target->length; i++) {
        for (int j = 0; j < filterSize; j++) {
            if (target->text[i] == filter[j]) {
                toFilter++;
            }
        }
        if (!toFilter) {
            buffer[counter] = target->text[i];
            counter++;
        }
        toFilter = 0;
    }
    int returner = target->length - counter;
    //target = stryngNew(buffer, counter);

    stryngModulate(target, counter);
    stryngWrite(buffer, target, target->length);

    /*slAdd(target);
    target->text = (char *) gimme(counter, sizeof(char));
    stryngWrite(buffer, target, counter);
    target->length = counter;*/
    return returner;
}

//! Replaces a Stryng within another with a third
/*!
  \param toReplace the Stryng that is to be replaced
  \param target the Stryng within wich is the be replaced
  \param replacer the Stryng that is to be written instead
  \return the amount of times something was replaced
*/
int stryngReplacer(char *toReplace, Stryng *target, char *replacer) {
    int counter = 0, setter = 0, internalCounter = 0, returner = 0, replen = (int) strlen(
            replacer), treplen = (int) strlen(toReplace);
    char buffer[treplen * target->length];
    for (int i = 0; counter < target->length; i++) { //for every Symbol
        if (target->text[counter + setter] == toReplace[setter]) { //check if it is our target
            setter++;
            if (setter >= treplen) { //if it is,
                for (int k = 0; k < replen; k++) {
                    buffer[internalCounter] = replacer[k];
                    internalCounter++;
                    counter++;
                }
                returner++;
            }
        } else {
            buffer[internalCounter] = target->text[counter];
            setter = 0;
            internalCounter++;
            counter++;
        }
    }
    //*target = stryngNew(buffer, internalCounter);

    stryngModulate(target, internalCounter);
    stryngWrite(buffer, target, target->length);

    /*slAdd(target);
    target->text = (char *) gimme(internalCounter, sizeof(char));
    stryngWrite(buffer, target, counter);
    target->length = internalCounter;*/
    return returner;
}

//! Replaces all uppercase letters with lowercase letters
/*!
  \param target the target Stryng
  \return the amount symbols changed
*/
int stryngToLower(Stryng *target) {
    int returner = 0;
    for (int i = 0; i < target->length; i++) {
        if (target->text[i] >= 65 && target->text[i] <= 90) {
            target->text[i] += 32;
            returner++;
        }
    }
    return returner;
}

//! Searches for 'search' within 'target'
/*!
  \param target the target Stryng
  \param search the char that is searched for
  \return the position of target where 'search' ends, or 0 if nothing found
*/
int stryngFind(Stryng target, char *search) {
    int setter = 0, i = 0, serlen = (int) strlen(search);
    while (i < target.length) {
        if (target.text[i] == search[setter]) {
            setter++;
        } else {
            if (setter >
                0) {      //in case of misfire, go back to where we started +1 symbol (so we don't get f'ed when
                i -= setter -
                     1;  //searching for eg. ab in aab (it would ignore the second a as misfire and move on to b)
            }
            setter = 0;
        }
        i++;
        if (setter >= serlen) {
            return i;
        }
    }
    return 0;
}

//! Searches for last 'search' within 'target'
/*!
  \param target the target Stryng
  \param search the searched for char*
  \return the position of target where 'search' ends, or 0 if nothing found
*/
int stryngFindLast(Stryng target, char *search) {
    int setter = 0, returner = 0, serlen = (int) strlen(search);
    for (int i = 0; i < target.length; i++) {
        if (target.text[i] == search[setter]) {
            setter++;
        } else {
            if (setter > 0) {
                i -= setter - 1;
            }
            setter = 0;
        }
        if (setter >= serlen) {
            returner = i;
            setter = 0;
        }
    }
    return returner;
}

//! Counts 'search' within 'target'
/*!
  \param target the target Stryng
  \param search the char* whose occurence within target is counted
  \return the position of target where 'search' ends, or 0 if nothing found
*/
int stryngCount(Stryng target, char *search) {
    int setter = 0, counter = 0, serlen = (int) strlen(search);
    for (int i = 0; i <= target.length; i++) {
        if (target.text[i] == search[setter]) {
            setter++;
            if (setter >= serlen) {
                counter++;
            }
        } else {
            setter = 0;
        }
    }
    return counter;
}

//! Converts 'stryng' into integer
/*!
    \param stryng the stryng that gets converted
    \return the value of the integer that got converted if return value = -1 its not a number that also means that
            negative numbers wont work
 */
int stryngToInt(Stryng stryng) {

    int value = 0, counter = 0, multiplicator = 1;
    while (counter < stryng.length) {
        multiplicator *= 10;
        counter++;
    }
    counter = 0;
    while (counter < stryng.length) {
        if ((stryng.text[counter]) >= '0' && (stryng.text[counter]) <= '9') {
            multiplicator /= 10;
            value += (multiplicator) * ((stryng.text[counter]) - '0');
            counter++;
        } else {
            return -1;
        }
    }

    return value;
}

//! Converts char to hex
/*!
    \param hex the char* to be converted
    \param amount the length of hex
    \return the hex-value, note that this function doesn't give a damn about other symbols
            and won't touch them even with a stick
 */
int hexToInt(char* hex, int amount) {
    int val = 0, tmp = 0;
    for (int i = 0; i < amount;i++) {
        if (hex[i] >= '0' && hex[i] <= '9') {
            tmp = hex[i] - '0';
        }
        else if (hex[i] >= 'a' && hex[i] <='f') {
            tmp = hex[i] - 'a' + 10;
        }
        else if (hex[i] >= 'A' && hex[i] <='F') {
            tmp = hex[i] - 'A' + 10;
        }
        val *= 16;
        val += tmp;
    }

    return val;
}

//! Converts 'stryng' into integer
/*!
    \param value the value that gets converted
    \return full Stryng
 */
Stryng intToStryng(int value) {
    char const digit[] = "0123456789";

    int tempvalue = value;
    int length = 0;

    while (tempvalue) {
        tempvalue /= 10;
        length++;
    }

    char buffer[length];
    char *pointer = buffer;
    pointer += length;

    do {//going back to the first position and saves up the value into the stryng from right to left
        *--pointer = digit[value % 10];
        value /= 10;
    } while (value);
    return stryngNew(buffer, length);
}


//! Initializes the pointer library struct "Stryngs"
void stryngInit() {
    Stryngs.new = stryngNew;
    Stryngs.liberate = stryngLiberate;
    Stryngs.split = stryngSplit;
    Stryngs.splitL = stryngSplitL;
    Stryngs.splitC = stryngSplitC;
    Stryngs.join = stryngJoin;
    Stryngs.fuse = stryngFuse;
    Stryngs.decode = stryngDecoder;
    Stryngs.filter = stryngFilter;
    Stryngs.replace = stryngReplacer;
    Stryngs.toLower = stryngToLower;
    Stryngs.conlion = stryngConcat;
    Stryngs.copy = stryngCopy;
    Stryngs.copyFrom = stryngCopyFrom;
    Stryngs.find = stryngFind;
    Stryngs.findLast = stryngFindLast;
    Stryngs.count = stryngCount;
    Stryngs.toInt = stryngToInt;
    Stryngs.toStryng = intToStryng;
}
