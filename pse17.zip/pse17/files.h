#include "strynglib.h"

//
// Created by dominik on 27.04.18.
//

#ifndef PSE18_FILES_H
#define PSE18_FILES_H

int loadFile(Stryng filepath, Stryng *content);
int getMime(Stryng filename, Stryng *mime);
int getFilePath(Stryng doc_root, Stryng resource, Stryng *path);
int getDocumentRoot(Stryng *doc_root, int virtual_hosting_state);
int getRealpath(Stryng path, Stryng *realPath);
int checkIfPathIsValid(Stryng realpath, int virtual_hosting_status);
int fileExists(Stryng filename);
int isRegularFile(Stryng path);
void appendIndexToFilename(Stryng *filename);

#endif //PSE18_FILES_H
