Pewpewlaz0rt4nk |version| Documentation
***************************************

Contents:

.. toctree::
   :maxdepth: 2
   :numbered:

   welcome
   tutorial
   advanced
   api

Indices and Tables
==================

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
