//
// Created by ms150591 on 25.04.18.
//
#include "strynglib.h"

#ifndef PSE18_ATTRIBUTES_H
#define PSE18_ATTRIBUTES_H

typedef struct Attribute{
    Stryng name;
    Stryng value;

} Attribute;

typedef struct AttributesList{
    struct Attribute attribute;
    struct AttributesList *next;
} AttributesList;


Attribute getAttribute(Stryng *attribute_str, int* code);
void readAttributes(AttributesList *list, Stryng lines[], int attr_count, int* code);
void appendAttribute(AttributesList *list, Attribute attribute);
void addAttribute(AttributesList *list, Stryng name, Stryng value);
AttributesList* initAttributesList();
int findAttribute(char* attributeName, AttributesList *list, Stryng *attribute);
void clearAttributesList(AttributesList *list);
void freeAttributesListItem(AttributesList *item);
#endif //PSE18_ATTRIBUTES_H
