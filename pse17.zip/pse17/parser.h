//
// Created by Dominik Roß on 17.04.18.
#include "strynglib.h"
#include "attributes.h"

#ifndef PSE18_PARSER_H
#define PSE18_PARSER_H

#define DOC_ROOT "/home/pse/htdocs"
#define DEFAULT_DOC_ROOT_FILE "index.html"

#define HTTP_VERSION "HTTP/1.1"
#define DEBUG_PAGE "/debug"

#define EXTERN_ROOT DOC_ROOT "/extern" //Concatenation of DOCROOT and "/extern" into EXTERN_ROOT
#define INTERN_ROOT DOC_ROOT "/intern"

#define FALSE 0
#define TRUE !(FALSE)

/**
 * Struct of the requestline, the first line of an HTTP request with METHOD, VERSION and RESOURCE
 */
typedef struct RequestLine{
    Stryng method;
    Stryng version;
    Stryng resource;
} RequestLine;

/**
 * Struct of the Statusline, the first line of an HTTP response with CODE, VERSION and REASON_PHRASE
 */
typedef struct StatusLine{
    Stryng code;
    Stryng version;
    Stryng reasonPhrase;
} StatusLine;

/**
 * The request is the requestline plus the attributes
 */
typedef struct Request{
    struct RequestLine requestLine;
    struct AttributesList *attributes;
} Request;

/**
 * The response is the statusline plus the attributes
 */
typedef struct Response{
    struct StatusLine statusLine;
    struct AttributesList *attributes;
} Response;

Stryng parse(Stryng request_str);
RequestLine readRequestLine(Stryng line, int*response_code);
Stryng getDebugPage(Request request);


#endif //PSE18_PARSER_H

