//
// Created by Nick Lohmann on 15.04.18.
//

#ifndef PSE18_STRYNGLIB_H
#define PSE18_STRYNGLIB_H

#define ALLOC_DELAY_FACTOR_MAX 10000 //maximum time delay between attempts to alloc/realloc memory

//! Creativly named wrapper function for calloc() that should wait for free memory if neccessary
/*!
  \param amount number of elements
  \param size the size(bytes) to be allocated
*/
void *gimme(int amount, int size);

//! the Stryng struct. alternative for string that doesn't give a damn about \0 bytes
typedef struct Stryng {
    char *text;
    int length;
} Stryng;

//! pointer library for Stryng struct. If stryngInit() is run, you can access all important functions from here similar to an object with methods
typedef struct Strynger {
    Stryng (*new)(char *text, int length);
    void (*liberate)(Stryng *target);
    int (*split)(Stryng source, Stryng (*target)[], char symbol, int maxSplit, int deleteEmpty);
    int (*splitL)(Stryng source, Stryng (*target)[], Stryng symbol, int maxSplit, int deleteEmpty);
    int (*splitC)(Stryng source, Stryng (*target)[], char* symbol, int maxSplit, int deleteEmpty);
    void (*join)(Stryng source[], Stryng *target, char* separator, int sizeOfSource);
    void (*fuse)(Stryng source[], Stryng *target, int sizeOfSource);
    int (*decode)(Stryng *target);
    int (*filter)(char filter[], Stryng *target, int filterSize);
    int (*replace)(char* toReplace, Stryng *target, char* replacer);
    int (*toLower)(Stryng *target);
    Stryng (*copy)(Stryng source, int amount);
    int (*conlion)(char* source, Stryng *target, int amount);
    Stryng (*copyFrom)(Stryng source, int amount, int indent);
    int (*find)(Stryng target, char* search);
    int (*findLast)(Stryng target, char* search);
    int (*count)(Stryng target, char* search);

    int (*toInt)(Stryng stryng);
    Stryng (*toStryng)(int value);
} Strynger;

//! Global instance of Strynger (pointer library for Stryng)
extern Strynger Stryngs;

//! internal function, use at your own peril. stryng-specific wrapper for realloc
/*!
  \param ptr the pointer to the to-be-reallocated memory
  \param content the text to be written into the memory
  \param amount the amount of Symbols to be written and new size of ptr
  \return the reallocated pointer
*/
Stryng* stryngModulate(Stryng* ptr,  int amount);

//! Copies text from one Stryng into another
/*!
  \param source the Stryng that is to be copied
  \param target the Stryng that is to be written into
  \param amount the amount of Symbols to be written, starts at [0]
*/
Stryng stryngCopy(Stryng source, int amount);

//! Copies text from one Stryng into another, with indent
/*!
  \param source the Stryng that is to be copied
  \param target the Stryng that is to be written into
  \param amount the amount of Symbols to be written, starts at indent
  \param indent where we start copying
*/
Stryng stryngCopyFrom(Stryng source, int amount, int indent);

//! Internal function, use at your own peril. Writes a char* into a hopefully allocated Stryng.text field
/*!
  \param source the char* that is to be written
  \param target the Stryng that is to be written into
  \param amount the amount of Symbols to be written, ideally the size of both source and target
*/
void stryngWrite(char* source, Stryng *target, int amount);

//! Creates a new Stryng (allocates memory and sets text and length)
/*!
  \param text the text to be written into the Stryngs .text field
  \param length the amount of memory allocated and the size of text which is written into the Stryngs .length field
  \return the created Stryng
*/
Stryng stryngNew(char *text, int length);

//! Frees allocated memory from a Stryng and sets its size to 0
/*!
  \param target the target Stryng
*/
void stryngLiberate(Stryng *target);

//! Splits the Stryng into an Array of Stryng
/*!
  \param source the Stryng that is to be split
  \param target[] the target Array
  \param symbol the symbol at which the Stryng is split
  \param maxSplit the amount of splits that can be made, should be the size of target[] or smaller
  \param deleteEmpty if this is >0, any empty Arrays will not be written into target (note that this does not fill up or delete the remaining space in the array)
  \return the amount of splits made
*/
int stryngSplit(Stryng source, Stryng (*target)[], char symbol, int maxSplit, int deleteEmpty);

//! Splits the Stryng into an Array of Stryng by another Stryng
/*!
  \param source the Stryng that is to be split
  \param target[] the target Array
  \param symbol the Stryng at which the source is split
  \param maxSplit the amount of splits that can be made, should be the size of target[] or smaller
  \param deleteEmpty if this is >0, any empty Arrays will not be written into target (note that this does not fill up or delete the remaining space in the array)
  \return the amount of splits made
*/
int stryngSplitL(Stryng source, Stryng (*target)[], Stryng symbol, int maxSplit, int deleteEmpty);

//! Splits the Stryng into an Array of Stryng by a char*
/*!
  \param source the Stryng that is to be split
  \param target[] the target Array
  \param symbol the char* at which the source is split
  \param maxSplit the amount of splits that can be made, should be the size of target[] or smaller
  \param deleteEmpty if this is >0, any empty Arrays will not be written into target (note that this does not fill up or delete the remaining space in the array)
  \return the amount of splits made
*/
int stryngSplitC(Stryng source, Stryng (*target)[], char* symbol, int maxSplit, int deleteEmpty);

//! Joins an Array of Stryng into a single one, with separators
/*!
  \param source[] Stryng Array that is to be joined
  \param target the target Stryng
  \param separator the char* that is placed in between the source texts
  \param sizeOfSource the size of the Source Array, since there is no way to read it within the function
*/
void stryngJoin(Stryng source[], Stryng *target, char* separator, int sizeOfSource);

//! Joins an Array of Stryng into a single one
/*!
  \param source[] Stryng Array that is to be joined
  \param target the target Stryng
  \param sizeOfSource the size of the source Array, since there is no way to read it within the function
*/
void stryngFuse(Stryng source[], Stryng *target, int sizeOfSource);

//! Decodes an URI encoded Stryng
/*!
  \param target the Stryng to be decoded
  \return the amount of Symbols decoded
*/
int stryngDecoder(Stryng *target);

//! Filters out a certain set of symbols
/*!
  \param filter Symbols to be filtered
  \param target the target Stryng
  \param filterSize amount of Symbols in the filter Array
  \return the amount of Symbols deleted
*/
int stryngFilter(char filter[], Stryng *target, int filterSize);

//! Replaces a Stryng within another with a third
/*!
  \param toReplace the char* that is to be replaced
  \param target the Stryng within wich is the be replaced
  \param replacer the char* that is to be written instead
  \return the amount of times something was replaced
*/
int stryngReplacer(char* toReplace, Stryng *target, char* replacer);

//! Replaces all uppercase letters with lowercase letters
/*!
  \param target the target Stryng
  \return the amount symbols changed
*/
int stryngToLower(Stryng *target);

//! Searches for 'search' within 'target'
/*!
  \param target the target Stryng
  \param search the searched for char*
  \return the position of target where 'search' ends, or 0 if nothing found
*/
int stryngFind(Stryng target, char* search);

//! Searches for last 'search' within 'target'
/*!
  \param target the target Stryng
  \param search the searched for char*
  \return the position of target where 'search' ends, or 0 if nothing found
*/
int stryngFindLast(Stryng target, char* search);

//! Counts 'search' within 'target'
/*!
  \param target the target Stryng
  \param search the char* whose occurrence within target is counted
  \return the position of target where 'search' ends, or 0 if nothing found
*/
int stryngCount(Stryng target, char* search);

//! Converts char to hex
/*!
    \param hex the char* to be converted
    \param amount the length of hex
    \return the hex-value, note that this function doesn't give a damn about other symbols
            and won't touch them even with a stick
 */
int hexToInt(char* hex, int amount);

//! Converts 'stryng' into integer
/*!
    \param stryng the stryng that gets converted
    \return the value of the integer that got converted
 */
int stryngToInt(Stryng stryng);

//! Converts 'stryng' into integer
/*!
    \param stryng the stryng the converted value and length gets saved into
    \param value the value that gets converted
    \return the value of the integer that got converted if return value = -1 its not a number that also means that
            negative numbers wont work
 */
Stryng intToStryng(int value);

//! Initializes the pointer library struct "Stryngs"
void stryngInit();


#endif //PSE18_STRYNGLIB_H
