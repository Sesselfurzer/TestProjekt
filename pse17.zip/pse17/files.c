//
// Created by dominik on 27.04.18.
//
#include "files.h"
#include "strynglib.h"
#include "parser.h"
#include "response.h"
#include <limits.h>
#include <error.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <unistd.h>

#define MIME_BUFFER 20

/**
 * append a default file name to the path
 * @param filename the path
 * @return gives back the path + a default path name (index.html in this case)
 */
void appendIndexToFilename(Stryng *filename)
{
    Stryng filename_buffer;
    Stryng file[2] = {*filename , Stryngs.new(DEFAULT_DOC_ROOT_FILE, (int)strlen(DEFAULT_DOC_ROOT_FILE))};
    Stryngs.join(file,&filename_buffer,"/",2);
    Stryngs.liberate(filename);
    Stryngs.liberate(&file[1]);
    *filename = filename_buffer;
}

/**
 * Checks if the path ending is a file or not
 * @param path the path of the file
 * @return gives back 0 if its not a file
 */
int isRegularFile(Stryng path)
{
    struct stat path_stat;
    stat(path.text, &path_stat);
    return S_ISREG(path_stat.st_mode);
}

/**
 * Gets the content of a given file out of a stream.
 * @param filepath Absoulut path to file
 * @param content Pointer to content of file
 * @return Content of file
 */
int loadFile(Stryng filepath, Stryng *content)
{
    FILE *fp;
    long lSize;
    char *buffer;

    /*
     * Open the file. That the file exists has already been tested
     */
    fp = fopen ( filepath.text , "rb" );
    if( !fp ) return FALSE;

    /*
     * Get the size of the file
     */
    fseek( fp , 0L , SEEK_END);
    lSize = ftell( fp );
    rewind( fp );

    /*
     * allocate memory for entire content
     */
    if(lSize <= 0)
    {
        fclose(fp);
        return FALSE;
    }

    buffer = gimme( 1, (int)lSize+1 );
    if( !buffer ){
        fclose(fp);
        return FALSE;
    }

    /*
     * copy the file into the buffer
     */
    if( 1!=fread( buffer , lSize, 1 , fp) ){
        fclose(fp);
        free(buffer);
        return FALSE;
    }

    /**
     * Save in Stryng
     * */
    *content = Stryngs.new(buffer, lSize);

    /*
     * Close file and free buffer
     */
    fclose(fp);
    free(buffer);

    return TRUE;
}

/**
 * Gets the HTTP Content-Type out of the filename
 * @param filename filename
 * @param mime Pointer to mime string
 * @return TRUE if mime found, FALSE if an error occured
 */
int getMime(Stryng filename, Stryng *mime) {
    /*
     * Get the text after the last '.'
     */
    char *dot = strrchr(filename.text, '.');
    if(!dot || dot == NULL) return FALSE;

    /*
     * Make the extension lower. Maybe in the request it is in
     * upper letters
     */
    Stryng ext = Stryngs.new(dot, (int)strlen(dot));
    Stryngs.toLower(&ext);

    /*
     * Get the correct mime. If the extension does not match
     * return "application/misc"
     */
    if(stryngFind(ext, ".html")==5)
        *mime = Stryngs.new("text/html", 9);
    else if(stryngFind(ext, ".jpg")==4)
        *mime = Stryngs.new("image/jpg", 9);
    else if(stryngFind(ext, ".jpeg")==5)
        *mime = Stryngs.new("image/jpeg", 10);
    else if(stryngFind(ext, ".png")==4)
        *mime = Stryngs.new("image/png", 9);
    else
        *mime = Stryngs.new("application/misc", 16);

    return TRUE;

}

/**
 * Get the document root. If virtual hosting is set, intern or extern
 * will be appended to the default root
 * @param doc_root document root
 * @param virtual_hosting_state the current state of virtual hosting
 * @return FALSE if there was an error
 */
int getDocumentRoot(Stryng *doc_root, int virtual_hosting_state) {
    switch (virtual_hosting_state){
        case no_vh: {
            *doc_root = Stryngs.new(DOC_ROOT, strlen(DOC_ROOT));
            break;
        }
        case extern_vh: {
            *doc_root = Stryngs.new(EXTERN_ROOT, strlen(EXTERN_ROOT));
            break;
        }
        case intern_not_authorised_vh: {
            return FALSE;
        }
        case intern_authorised_vh:{
            //TODO in P4
        }
    }
}

/**
 * Concatenates the doc_root and resource into the path
 * @param resource Resource of HTTP request
 * @param doc_root The document root
 * @param path Pointer to path
 * @return TRUE if it works
 */
int getFilePath(Stryng doc_root, Stryng resource, Stryng *path) {
    /*
     * Concatenate the path
     */
    Stryng fullpath_parts [2] = { doc_root, resource};
    Stryngs.fuse(fullpath_parts, path, 2);

    return TRUE;
}

/**
 * Get canonicalized absolute pathname. Makes use of realpath which
 * expands all symbolic links and resolves references to /./,
 * /../ and extra '/' characters in the null-terminated string named by
 * path to produce a canonicalized absolute pathname.
 * @param path Path to resolve
 * @param realPath Resolved Path
 * @return TRUE if resolved succesfully, else FALSE
 */
int getRealpath(Stryng path, Stryng *realPath)
{
    char buf[PATH_MAX + 1];
    char *rp = realpath(path.text, buf);

    /*
   * There is an error like 'No such file or directory'. Set realpath NULL
   * and save the status code
   */
    if (!rp)
    {
        realPath = NULL;
        return FALSE;
    }

    *realPath= Stryngs.new(rp, (int)strlen(rp));

    return TRUE;
}

/**
 * Checks if the path is in an allowed path in the document root
 * @param realpath realpath
 * @param virtual_hosting_status status of virtual hosting
 * @return FALSE if something went wrong else TRUE
 */
int checkIfPathIsValid(Stryng realpath, int virtual_hosting_status)
{
    /*
     * Compare the first characters of the realpath with the document root
     * until the lenth of the document root is reached. If they are equally
     * return TRUE, else FALSE
     */
    int  pos = Stryngs.find(realpath, DOC_ROOT);
    if(pos != strlen(DOC_ROOT))
    {
        return FALSE;
    }

    /*
     * Same principle for the inter and extern path if the
     * host attribute is not set to host: intern or host: extern
     * because you don't want access to the folder if the
     * attributes are not set
     */
    if(virtual_hosting_status != extern_vh)
    {
        int  pos = Stryngs.find(realpath, EXTERN_ROOT);
        if(pos == strlen(EXTERN_ROOT))
        {
            return FALSE;
        }
    }

    if(virtual_hosting_status != intern_authorised_vh)
    {
        int  pos = Stryngs.find(realpath, INTERN_ROOT);
        if(pos == strlen(INTERN_ROOT))
        {
            return FALSE;
        }
    }

    return TRUE;
}

/**
 * Checks if an file exists
 * @param filename name of file to check
 * @return TRUE if file exists TRUE, else FALSE
 */
int fileExists(Stryng filename)
{
    FILE *file;
    if ((file = fopen(filename.text, "r")))
    {
        fclose(file);
        return TRUE;
    }
    return FALSE;
}

