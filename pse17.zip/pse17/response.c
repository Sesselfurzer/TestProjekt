//
// Created by ms150591 on 25.04.18.
//
#include "strynglib.h"
#include "parser.h"
#include "attributes.h"
#include "response.h"
#include "files.h"
#include <limits.h>
#include <error.h>
#include <errno.h>
#include <time.h>
#include <ctype.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>

/**
 * checks the request for errors and creates the realpath
 * @param request request that needs to be checked
 * @param code errorcode
 * @param realPath the full path gets written into this Stryng
 * @param debug_mode TRUE if /debug is in the resource
 * @return TRUE if everyone worked as intended, FALSE if there was an error
 */
int searchThroughRequest(Request request, int *code, Stryng *realPath, int *debug_mode)
{
    Stryng path, document_root;

    if(*code==501)
    {
        return FALSE;
    }

    if (stryngFind(request.requestLine.resource,"/debug") == 6)
    {
        *debug_mode = TRUE;
        return TRUE;
    }

    Stryng host_value;
    int virtual_hosting_status = no_vh;
    if(findAttribute("host",request.attributes, &host_value))
    {
        if(virtualHosting(host_value, &virtual_hosting_status))
        {
            if(virtual_hosting_status == intern_not_authorised_vh){
                *code = 401;
                return FALSE;
            }
        }
    }

    if(!getDocumentRoot(&document_root, virtual_hosting_status))
    {
        *code = 500;
        Stryngs.liberate(&document_root);
        return FALSE;
    }

    if(!getFilePath(document_root, request.requestLine.resource, &path))
    {
        *code = 500;
        Stryngs.liberate(&path);
        Stryngs.liberate(&document_root);
        return FALSE;
    }

    Stryngs.liberate(&document_root);

    if (!getRealpath(path, realPath))
    {
        *code = 404;
        Stryngs.liberate(&path);
        return FALSE;
    }

    Stryngs.liberate(&path);

    if(!checkIfPathIsValid(*realPath, virtual_hosting_status))
    {
        Stryngs.liberate(realPath);
        *code = 403;
        return FALSE;
    }

    if(!isRegularFile(*realPath))
    {
        appendIndexToFilename(realPath);
    }

    if(!fileExists(*realPath))
    {
        Stryngs.liberate(realPath);
        *code = 404;
        return FALSE;
    }

    return TRUE;
}

/**
 * Generate an response based on the data in the response struct
 * @param response Pointer to response that get used to create the response "Stryng"
 * @param request Pointer to request so that this method has all the infos about the request
 * @param status_code the status code that get changed if something went wrong
 * @return Full valid HTTP response
 */
Stryng generate_response(Response *response, Request *request, int *status_code)
{
    int check_request, get_body=FALSE, debug_mode = FALSE;
    Stryng body, header, response_text, fileRealPath;

    if(*status_code == 200) { //No error until no? (There could be an error in parse())
        check_request = searchThroughRequest(*request, status_code, &fileRealPath, &debug_mode);
        if (check_request) {
            get_body = getResponseBody(fileRealPath, status_code, &body, debug_mode,
                                       *request); //The file could maybe not be loaded
        }
    }
    else{
        check_request = FALSE;
    }

    /*
     * Is there no problem with the transfered HTTP Parameters?
     */
    if(check_request == FALSE || get_body == FALSE)
    {
        /*
         * If there is a problem get the error page
         */
        response->statusLine.code = intToStryng(*status_code);
        response->statusLine.reasonPhrase = getHTTPStatusPhrase(*status_code);
        body = getErrorPageBody(response->statusLine.code, response->statusLine.reasonPhrase);
    }
    else
    {
        response->statusLine.code = Stryngs.new("200", 3);
        response->statusLine.reasonPhrase = getHTTPStatusPhrase(*status_code);
    }

    /*
     * We want definitely the response header
     */
    header = getResponseHeader(response, body.length);

    /*
     * Join the header and body into one String
     */
    Stryng response_parts [2] = { header, body };
    stryngJoin(response_parts, &response_text, "\n",2 );

    Stryngs.liberate(&header);
    Stryngs.liberate(&body);
    if (check_request && debug_mode==FALSE) {
        Stryngs.liberate(&fileRealPath);
    }


    return response_text;
}



/**
 * Fills the response list and gets the header string out of them
 * @param response Pointer to Response
 * @param bodylength full length of the bodypart of the response
 * @return full response text
 */
Stryng getResponseHeader(Response *response, int bodylength){
    int status_code = stryngToInt(response->statusLine.code);
    /**
     * Add Atributes to list
     */
    addAttribute(response->attributes, Stryngs.new("Date", 4), getHTTPDate());
    addAttribute(response->attributes, Stryngs.new("Server", 6), Stryngs.new("MNDServer",9));
    addAttribute(response->attributes, Stryngs.new("Content-Length", 14), Stryngs.toStryng(bodylength));

    if(status_code == 401)
    {
        addAttribute(response->attributes, Stryngs.new("WWW-Authenticate", 16), Stryngs.new("Basic", 7));
    }

    addAttribute(response->attributes, Stryngs.new("Connection", 10),  Stryngs.new("keep-alive\r\n", 12));


    /**
     * creating the text for response
     */
    response->statusLine.version = Stryngs.new(HTTP_VERSION, strlen(HTTP_VERSION));
    //response->statusLine.reasonPhrase = getHTTPStatusPhrase(status_code);

    Stryng responseText;
    Stryng responseTextPiece[2];
    Stryng responseStatusLine[3] = {response->statusLine.version, response->statusLine.code, response->statusLine.reasonPhrase  };

    stryngJoin(responseStatusLine,&responseTextPiece[0], " ",3 );

    Stryng temp;
    AttributesList * current = response->attributes->next;
    Stryng responseHeader[2];

    while(current != NULL){
        responseHeader[0]=current->attribute.name;
        responseHeader[1]=current->attribute.value;
        stryngJoin(responseHeader, &responseTextPiece[1],": ",2);
        stryngJoin(responseTextPiece, &temp, "\n", 2);
        Stryngs.liberate(&responseTextPiece[1]);
        Stryngs.liberate(&responseTextPiece[0]);
        responseTextPiece[0]=temp;
        current = current->next;
    }
    responseText=temp;


    return responseText;
}

/**
* Creates the Body of the response: reads the requested resource file into
* an Stryng
* @param validatedRealPath realpath of the resource
* @param code status code gets changed if something went wrong
* @param body the body Stryng gets saved into this Stryng
* @param debug_mode if TRUE it creates the body of the debugPage
* @param request Pointer to Request
* @return TRUE if there was no error else FALSE
*/
int getResponseBody(Stryng validatedRealPath, int *code, Stryng *body, int debug_mode, Request request)
{
    if(debug_mode)
    {
        *body = getDebugPage(request);
        return TRUE;
    }

    if(!loadFile(validatedRealPath, body))
    {
        *code = 500;
        return FALSE;
    }

    return TRUE;
}

/**
 * Return the current timestamp formatted into HTTP date format
 * @return HTTP current date
 */
Stryng getHTTPDate()
{
    char time_buf[1000];
    time_t now = time(0);
    struct tm tm = *gmtime(&now);
    strftime(time_buf, sizeof time_buf, "%a, %d %b %Y %H:%M:%S %Z", &tm);

    return Stryngs.new(time_buf, (int)strlen(time_buf));
}

/**
 * Returns the reason phrase beloning to an given HTTP status code
 * @param code HTTP status code
 * @return HTTP status phrase
 */
Stryng getHTTPStatusPhrase(int code)
{
    Stryng status;
    switch (code)
    {
        case 200: status=Stryngs.new("OK",2); break;
        case 201: status=Stryngs.new("Created",7); break;
        case 202: status=Stryngs.new("Accepted",8); break;
        case 204: status=Stryngs.new("No Content",10); break;
        case 301: status=Stryngs.new("Moved Permanently",17); break;
        case 302: status=Stryngs.new("Moved Temporarily",17); break;
        case 304: status=Stryngs.new("Not Modified",12); break;
        case 400: status=Stryngs.new("Bad Request",11); break;
        case 401: status=Stryngs.new("Unauthorized",12); break;
        case 403: status=Stryngs.new("Forbidden",9); break;
        case 404: status=Stryngs.new("Not Found",9); break;
        case 500: status=Stryngs.new("Internal Server Error",21); break;
        case 501: status=Stryngs.new("Not Implemented",15); break;
        case 502: status=Stryngs.new("Bad Gateway",11); break;
        case 503: status=Stryngs.new("Service Unavailable",19); break;
        default:  status=Stryngs.new("Error Code not Found",20); break;
    }
    return status;
}

/**
 * creates the ErrorPageBody
 * @param errorCode current errorcode
 * @param reasonPhrase the reason phrase that was created by getHTTPStatusPhrase
 * @return a Stryng of the body
 */
Stryng getErrorPageBody(Stryng errorCode, Stryng reasonPhrase)
{
    char begin_text[] = {"<html>\n <body>\n  <h1>ERROR"};
    char end_text[] = {"</h1>\n </body>\n</html> "};
    Stryng errorPagePieces[4]={Stryngs.new(begin_text, strlen(begin_text)),
                           errorCode,
                           reasonPhrase,
                           Stryngs.new(end_text,strlen(end_text))};
    Stryng errorPageText;
    Stryngs.join(errorPagePieces, &errorPageText, " ",4);
    Stryngs.liberate(&errorPagePieces[0]);
    Stryngs.liberate(&errorPagePieces[3]);
    return errorPageText;

}

/**
 * change the resource if specific hosts are found
 * @param attribute search in this attribute
 * @param realPath the current realpath that gets changed if a specific host is found
 * @param response_code the current code which gets changed if there is an error
 * @return True if something was found, False if nothing was found
 */
int virtualHosting(Stryng attribute, int *virtual_hosting_status)
{
    if(Stryngs.find(attribute,"extern")==attribute.length) {
        *virtual_hosting_status = extern_vh;
        return TRUE;
    }
    else if(Stryngs.find(attribute,"intern")==attribute.length) {
        *virtual_hosting_status = intern_not_authorised_vh;
        return TRUE;
    }

    *virtual_hosting_status = no_vh;
    return FALSE;
}
