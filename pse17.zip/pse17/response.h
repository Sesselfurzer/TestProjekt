//
// Created by ms150591 on 25.04.18.
//
#include "strynglib.h"
#include "parser.h"


#ifndef PSE18_RESPONSE_H
#define PSE18_RESPONSE_H
/**
 * Enum for different status of virtual hosting
 */
enum virtual_hosting_states {
    no_vh = 0,                      //No Virtual Host in Request
    extern_vh = 1,                  //Host: extern is set
    intern_not_authorised_vh = 2,   //Host: intern is set but not authorised
    intern_authorised_vh = 3        //Host: intern is set and authorised
};



Stryng generate_response(Response *response, Request *request, int *response_code);
Stryng getResponseHeader(Response *response, int bodylength);
int getResponseBody(Stryng validatedRealPath, int *code, Stryng *body, int debug_mode, Request request);
int searchThroughRequest(Request request, int *code, Stryng *realPath, int *debug_mode);
Stryng getHTTPDate();
Stryng getHTTPStatusPhrase(int code);
Stryng getErrorPageBody(Stryng errorCode, Stryng reasonPhrase);
int virtualHosting(Stryng attribute, int *virtual_hosting_status);
#endif //PSE18_RESPONSE_H
